@echo off
setlocal enabledelayedexpansion

if not exist "data\" (
    echo [ERROR] data folder not found!
    pause
    exit /b
)

if not exist "data\tropius-client.json" (
    echo [ERROR] tropius-client.json not found in data folder!
    pause
    exit /b
)

set /p newver=Enter new Minecraft version (e.g. 1.12.2): 

set tempfile=%temp%\tmp_json_edit.txt

(for /f "usebackq delims=" %%A in ("data\tropius-client.json") do (
    set line=%%A
    set line=!line:1.8.9=%newver%!
    echo !line!
)) > "%tempfile%"

move /y "%tempfile%" "data\tropius-client.json" >nul

echo [SUCCESS] Version updated to %newver%!
pause