@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "SOURCE_DIR=%SCRIPT_DIR%data"
set "VERSION_NAME=tropius-client"
set "DEST_DIR=%APPDATA%\.minecraft\versions\%VERSION_NAME%"

if not exist "%SOURCE_DIR%\tropius-client.jar" (
    echo .jar file was not found
    pause
    exit /b
)
if not exist "%SOURCE_DIR%\tropius-client.json" (
    echo .json file was not found
    pause
    exit /b
)

mkdir "%DEST_DIR%" 2>nul

copy "%SOURCE_DIR%\tropius-client.jar" "%DEST_DIR%\%VERSION_NAME%.jar" >nul
copy "%SOURCE_DIR%\tropius-client.json" "%DEST_DIR%\%VERSION_NAME%.json" >nul

echo Done! You successfully installed Tropius Client.
echo To use it: open Minecraft Launcher, create a new installation,
echo choose version tropius client have in mind this is aplha, and set the game directory to:
echo %DEST_DIR%
pause
